<script setup>
import { ModalsContainer } from 'vue-final-modal'
</script>

<template>
  <ModalsContainer />
  <RouterView />
</template>

<style scoped></style>
