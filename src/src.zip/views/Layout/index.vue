<script setup>
import LayoutNav from '@/views/Layout/components/LayoutNav.vue'
</script>

<template>
  <LayoutNav></LayoutNav>
  <RouterView />
</template>

<style scoped lang="scss">

</style>
